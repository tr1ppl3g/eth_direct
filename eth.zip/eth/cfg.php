<?php

// Isi Semua Data Dibawah Dengan Benar Ya !!!
// Jangan Sampai Salah Agar Tidak Error
// Jangan Lupa Support Channel Bocah Antik Official

$wallet = "XXxxxx";
